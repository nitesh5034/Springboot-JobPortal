<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Profile</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>

<%
    // Session mathi object lo
    com.model.UserModel u = (com.model.UserModel) session.getAttribute("Model");
    
    // Jo u null hoy to crash rokva mate khali check (Tame login validation nathi mangta atle redirect nahi kariye)
%>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow p-4">
                <h3 class="mb-4 text-primary">✏️ Edit Your Profile</h3>
                <form action="UserController" method="post">
                    <input type="hidden" name="action" value="updateProfile">
                    
                    <input type="hidden" name="userid" value="<%= (u != null) ? u.getUserid() : 0 %>">

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">First Name</label>
                            <input type="text" name="fname" class="form-control" 
                                   value="<%= (u != null && u.getFirstname() != null) ? u.getFirstname() : "" %>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Last Name</label>
                            <input type="text" name="lname" class="form-control" 
                                   value="<%= (u != null && u.getLastname() != null) ? u.getLastname() : "" %>">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" 
                               value="<%= (u != null && u.getEmail() != null) ? u.getEmail() : "" %>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Contact Number</label>
                        <input type="text" name="contact" class="form-control" 
                               value="<%= (u != null && u.getContact() != null) ? u.getContact() : "" %>">
                    </div>

                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label">City</label>
                            <input type="text" name="city" class="form-control" 
                                   value="<%= (u != null && u.getCity() != null) ? u.getCity() : "" %>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Pincode</label>
                            <input type="number" name="pincode" class="form-control" 
                                   value="<%= (u != null) ? u.getPincode() : 0 %>">
                        </div>
                    </div>

                    <div class="mt-4">
                        <button type="submit" class="btn btn-success px-5">Save Changes</button>
                        <a href="viewprofile.jsp" class="btn btn-secondary ms-2">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

</body>
</html>