<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Company Profile</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<!-- Header -->
<header class="bg-primary text-white text-center py-5">
  <h1>My Company Pvt Ltd</h1>
  <p>Delivering Excellence Since 2020</p>
</header>

<!-- Company Info Section -->
<section class="container my-5">
  <h2 class="mb-4">Company Information</h2>
  <div class="row mb-3">
    <div class="col-md-6">
      <strong>Company Name:</strong> My Company Pvt Ltd
    </div>
    <div class="col-md-6">
      <strong>Email:</strong> info@mycompany.com
    </div>
  </div>
  <div class="row mb-3">
    <div class="col-md-6">
      <strong>Website:</strong> www.mycompany.com
    </div>
    <div class="col-md-6">
      <strong>Location:</strong> Mumbai, India
    </div>
  </div>
  <div class="row">
    <div class="col-12">
      <strong>About:</strong>
      <p>We are a team of passionate professionals committed to delivering high-quality services to our clients. Our expertise spans web development, mobile apps, and digital marketing.</p>
    </div>
  </div>
</section>

<!-- Services Section -->
<section class="bg-light py-5">
  <div class="container">
    <h2 class="text-center mb-4">Our Services</h2>
    <div class="row text-center">
      <div class="col-md-4 mb-3">
        <div class="card p-3">
          <h5>Web Development</h5>
          <p>Creating responsive and dynamic websites.</p>
        </div>
      </div>
      <div class="col-md-4 mb-3">
        <div class="card p-3">
          <h5>Mobile Apps</h5>
          <p>Building modern mobile applications for all platforms.</p>
        </div>
      </div>
      <div class="col-md-4 mb-3">
        <div class="card p-3">
          <h5>Digital Marketing</h5>
          <p>Helping businesses grow online with effective marketing.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Team Section -->
<section class="container my-5">
  <h2 class="text-center mb-4">Our Team</h2>
  <div class="row text-center">
    <div class="col-md-4">
      <img src="https://via.placeholder.com/150" class="rounded-circle mb-2" alt="Team Member">
      <h5>John Doe</h5>
      <p>CEO</p>
    </div>
    <div class="col-md-4">
      <img src="https://via.placeholder.com/150" class="rounded-circle mb-2" alt="Team Member">
      <h5>Jane Smith</h5>
      <p>CTO</p>
    </div>
    <div class="col-md-4">
      <img src="https://via.placeholder.com/150" class="rounded-circle mb-2" alt="Team Member">
      <h5>Mark Wilson</h5>
      <p>Designer</p>
    </div>
  </div>
</section>

<!-- Latest Posts Section -->
<section class="bg-light py-5">
  <div class="container">
    <h2 class="text-center mb-4">Latest Posts</h2>
    <div class="row">
      <div class="col-md-4 mb-3">
        <div class="card p-3">
          <h5>How to Build a Modern Website</h5>
          <p>Learn tips and tricks to design responsive websites efficiently.</p>
        </div>
      </div>
      <div class="col-md-4 mb-3">
        <div class="card p-3">
          <h5>Mobile App Development Trends 2026</h5>
          <p>Stay updated with the latest mobile app technologies and trends.</p>
        </div>
      </div>
      <div class="col-md-4 mb-3">
        <div class="card p-3">
          <h5>Boost Your Business with Digital Marketing</h5>
          <p>Effective marketing strategies to increase online presence.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Contact Section -->
<section class="container py-5">
  <h2 class="text-center mb-4">Contact Us</h2>
  <form class="row g-3">
    <div class="col-md-6">
      <input type="text" class="form-control" placeholder="Your Name">
    </div>
    <div class="col-md-6">
      <input type="email" class="form-control" placeholder="Your Email">
    </div>
    <div class="col-12">
      <textarea class="form-control" rows="4" placeholder="Your Message"></textarea>
    </div>
    <div class="col-12 text-center">
      <button type="submit" class="btn btn-primary">Send Message</button>
    </div>
  </form>
</section>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

