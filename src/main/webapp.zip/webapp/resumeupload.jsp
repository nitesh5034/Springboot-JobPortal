<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Resume | Professional Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; }
        .upload-card { border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        .btn-primary { background-color: #007bff; border: none; }
        #statusMessage { font-weight: bold; }
    </style>
</head>
<body>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card upload-card p-4">
                <h3 class="text-center mb-4 text-primary">Upload Your Resume</h3>
                <p class="text-muted text-center">Please upload your resume in PDF format (Max 2MB).</p>
                
                <form id="uploadForm">
                    <div class="mb-3">
                        <label for="resume" class="form-label">Select File</label>
                        <input class="form-control" type="file" id="resume" name="resume" accept=".pdf,.doc,.docx" required>
                    </div>
                    
                    <div class="d-grid gap-2">
                        <button type="submit" id="submitBtn" class="btn btn-primary btn-lg">Submit Application</button>
                    </div>
                </form>

                <div id="statusMessage" class="mt-3 text-center"></div>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('uploadForm').addEventListener('submit', function(e) {
    e.preventDefault(); 

    const status = document.getElementById('statusMessage');
    const submitBtn = document.getElementById('submitBtn');
    const formData = new FormData(this);

    submitBtn.disabled = true;
    status.innerHTML = '<div class="text-info">Uploading, please wait...</div>';
    fetch('UploadServlet', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (response.ok) {
            return response.text();
        }
        throw new Error('Network response was not ok.');
    })
    .then(data => 
    {   
        status.innerHTML = '<div class="alert alert-success">✅ ' + "File Uploaded Successfully!" + '</div>';
        this.reset(); 
    })
    .catch(error => {
        status.innerHTML = '<div class="alert alert-danger">❌ Error: ' + error.message + '</div>';
    })
    .finally(() => {
        submitBtn.disabled = false;
    });
});
</script>

</body>
</html>