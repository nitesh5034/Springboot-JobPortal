<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<!-- ================= FOOTER ================= -->

<footer class="site-footer">

  <a href="#top" class="smoothscroll scroll-top">
    <span class="icon-keyboard_arrow_up"></span>
  </a>

  <div class="container">
    <div class="row mb-5">

      <div class="col-6 col-md-3">
        <h3>Search Trending</h3>
        <ul class="list-unstyled">
          <li><a href="#">Web Design</a></li>
          <li><a href="#">Graphic Design</a></li>
          <li><a href="#">Web Developers</a></li>
          <li><a href="#">Python</a></li>
          <li><a href="#">HTML5</a></li>
          <li><a href="#">CSS3</a></li>
        </ul>
      </div>

      <div class="col-6 col-md-3">
        <h3>Company</h3>
        <ul class="list-unstyled">
          <li><a href="#">About Us</a></li>
          <li><a href="#">Career</a></li>
          <li><a href="#">Blog</a></li>
          <li><a href="#">Resources</a></li>
        </ul>
      </div>

      <div class="col-6 col-md-3">
        <h3>Support</h3>
        <ul class="list-unstyled">
          <li><a href="#">Support</a></li>
          <li><a href="#">Privacy</a></li>
          <li><a href="#">Terms of Service</a></li>
        </ul>
      </div>

      <div class="col-6 col-md-3">
        <h3>Contact Us</h3>
        <div class="footer-social">
          <a href="#"><span class="icon-facebook"></span></a>
          <a href="#"><span class="icon-twitter"></span></a>
          <a href="#"><span class="icon-instagram"></span></a>
          <a href="#"><span class="icon-linkedin"></span></a>
        </div>
      </div>

    </div>

    <div class="row text-center">
      <div class="col-12">
        <p class="copyright">
          <small>
            Copyright &copy;
            <script>document.write(new Date().getFullYear());</script>
            All rights reserved | Made by Colorlib
          </small>
        </p>
      </div>
    </div>

  </div>
</footer>

<!-- ================= END FOOTER ================= -->

    </body>
  
  </div>
</html>
</body>
</html>