<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>User Profile</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>

<%
    com.model.UserModel u = (com.model.UserModel) session.getAttribute("Model");
    if(u == null) 
    {
        u = new com.model.UserModel(); 
    }
%>

<div class="container mt-5">
    <div class="row">
        <div class="col-md-4">
            <div class="card text-center p-3 shadow-sm border-0">
                <img src="images/user_avatar.png" class="rounded-circle mx-auto" width="100" alt="Profile">
                <h3 class="mt-2"><%= (u.getFirstname() != null) ? u.getFirstname() : "Guest" %></h3>
                <p class="badge bg-secondary"><%= (u.getRole() != null) ? u.getRole() : "No Role" %></p>
            </div>
        </div>
       
        <div class="col-md-8">
            <div class="card p-4 shadow-sm border-0">
                <h4 class="text-primary">📋 Profile Information</h4>
                <hr>
                <div class="row mt-3">
                    <div class="col-6 text-muted">Full Name:</div>
                    <div class="col-6"><strong><%= u.getFirstname() %> <%= u.getLastname() %></strong></div>
                </div>
                <div class="row mt-3">
                    <div class="col-6 text-muted">Email:</div>
                    <div class="col-6"><%= u.getEmail() %></div>
                </div>
                <div class="row mt-3">
                    <div class="col-6 text-muted">Contact:</div>
                    <div class="col-6"><%= u.getContact() %></div>
                </div>
                <div class="row mt-3">
                    <div class="col-6 text-muted">City:</div>
                    <div class="col-6"><%= u.getCity() %>, <%= u.getState() %></div>
                </div>
                <div class="row mt-3">
                    <div class="col-6 text-muted">Pincode:</div>
                    <div class="col-6"><%= u.getPincode() %></div>
                </div>
                
                <div class="mt-4 pt-3 border-top">
                    <a href="EditProfile.jsp" class="btn btn-primary px-4">Edit Profile</a>
                    <a href="Application-track.jsp" class="btn btn-outline-dark px-4 ms-2">Tracker</a>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>