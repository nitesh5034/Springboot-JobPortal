<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.model.UserModel, java.sql.*, java.util.*, java.io.*" %>
<%
    // Session mathi user object lavva mate (Validation nikadi didhu che)
    UserModel u = (UserModel) session.getAttribute("Model");
    
    // AI Logic (Mock)
    String aiResult = "";
    if(request.getParameter("generateAI") != null) {
        String skills = request.getParameter("user_skills");
        aiResult = "🚀 <b>AI Suggestion:</b> Based on '" + skills + "', add 'Agile' and 'Microservices'!";
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>User Dashboard | JobBoard</title>
    <link rel="stylesheet" href="css/custom-bs.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        .tracking-container { padding: 50px 0; background: #f9f9f9; }
        .card-custom { background: #fff; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); padding: 30px; margin-bottom: 30px; }
        .status-pill { padding: 5px 15px; border-radius: 50px; font-size: 13px; font-weight: 600; }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-hired { background: #d4edda; color: #155724; }
        .status-rejected { background: #f8d7da; color: #721c24; }
        .ai-assistant { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; }
    </style>
</head>
<body>

    <div class="site-navbar mt-3">
        <div class="container"><div class="site-logo"><a href="index.jsp">JobBoard</a></div></div>
    </div>

    <section class="section-hero overlay bg-image" style="background-image: url('images/hero_1.jpg'); height: 200px;">
        <div class="container text-center">
            <h2 class="text-white pt-5">User Dashboard</h2>
        </div>
    </section>

    <div class="col-lg-8">
    <div class="card-custom">
        <h4>📊 All Submitted Applications</h4>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Job ID</th>
                        <th>Candidate Name</th>
                        <th>Email</th>
                        <th>Experience</th>
                        <th>Status</th>
                        <th>Resume</th>
                    </tr>
                </thead>
                <tbody>
                    <%
                        try {
                            Class.forName("com.mysql.jdbc.Driver");
                            // TODO: Tamara DB Name ane Password check karjo
                            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jobportal", "root", "");
                            
                            // Badha j data fetch karva mate
                            String sql = "SELECT * FROM apply ORDER BY app_id DESC";
                            PreparedStatement ps = con.prepareStatement(sql);
                            
                            ResultSet rs = ps.executeQuery();
                            while(rs.next()) {
                                String status = rs.getString("status"); // Default 'pending'
                                
                                // Status wise CSS
                                String css = "status-pending"; 
                                if("Approved".equalsIgnoreCase(status)) css = "status-hired";
                                if("Rejected".equalsIgnoreCase(status)) css = "status-rejected";
                    %>
                    <tr>
                        <td>#<%= rs.getInt("job_id") %></td> <td><b><%= rs.getString("fullname") %></b></td>
                        <td><%= rs.getString("email") %></td>
                        <td><%= rs.getString("experience") %></td> <td><span class="status-pill <%= css %>"><%= status %></span></td>
                        <td>
                            <a href="uploads/<%= rs.getString("resume") %>" target="_blank" class="btn btn-sm btn-outline-info">View</a>
                        </td>
                    </tr>
                    <% 
                            }
                            con.close();
                        } catch(Exception e) {
                            out.print("System Message: " + e.getMessage());
                        }
                    %>
                </tbody>
            </table>
        </div>
    </div>
</div>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>