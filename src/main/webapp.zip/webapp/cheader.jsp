<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@ page import="com.model.UserModel" %>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Header</title>
</head>
<body>
 
<!-- ================= HEADER / NAVBAR ================= -->

<header class="site-navbar mt-3">
  <div class="container-fluid">
    <div class="row align-items-center">

      <div class="site-logo col-6">
        <a href="index.html">Jobportal</a>
      </div>

      <nav class="mx-auto site-navigation">
        <ul class="site-menu js-clone-nav d-none d-xl-block ml-0 pl-0">
          <li><a href="index.html" class="nav-link active">Home</a></li>
          <li><a href="about.jsp">About</a></li>

          <li class="has-children">
            <a href="joblisting.jsp">Job Listings</a>
            <ul class="dropdown">
              <li><a href="jobsingle.jsp">Job Single</a></li>
            </ul>
          </li>

          <li class="has-children">
            <a href="services.html">Pages</a>
            <ul class="dropdown">
              <li><a href="service.jsp">Services</a></li>
              <li><a href="service-single.jsp">Service Single</a></li>
              <li><a href="blog-single.jsp">Blog Single</a></li>
              <li><a href="portfolio.jsp">Portfolio</a></li>
              <li><a href="portfolio-single.jsp">Portfolio Single</a></li>
              <li><a href="testimonials.jsp">Testimonials</a></li>
              <li><a href="faq.jsp">FAQ</a></li>
              <li><a href="gallery.jsp">Gallery</a></li>
            </ul>
          </li>

          <li><a href="blog.jsp">Blog</a></li>
          <li><a href="contact.jsp">Contact</a></li>

          <!-- ✅ WELCOME USER -->
          <li class="has-children">
<div class="user-welcome">

        <a href="login.jsp">Welcome,<%=session.getAttribute("firstname") %></a>
    
</div>            <ul class="dropdown">
              <li><a href="Setting.jsp">Setting</a></li>
              <li><a href="ViewProfile.jsp">View Profile</a></li>
              <li><a href="Application-track.jsp">My Applications (Tracker)</a></li>
              <li><a href="resumeupload.jsp">Resume Section</a></li>
              <li><a href="login.jsp">Logout</a></li>
              
            </ul>
          </li>

        </ul>
      </nav>

      <div class="right-cta-menu text-right d-flex align-items-center col-6">
        <div class="ml-auto">
          <a href="login.jsp" class="btn btn-primary border-width-2 d-none d-lg-inline-block">
            <span class="mr-2 icon-lock_outline"></span>Log In
          </a>
        </div>

        <a href="#" class="site-menu-toggle js-menu-toggle d-inline-block d-xl-none ml-3">
          <span class="icon-menu h3 m-0 p-0"></span>
        </a>
      </div>

    </div>
  </div>
</header>

<!-- ================= END HEADER ================= -->

</body>
</html>
