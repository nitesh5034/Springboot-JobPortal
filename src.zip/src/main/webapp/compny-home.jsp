<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.model.UserModel" %>
<%@ page import="com.dao.CompanyDao" %>
<%@ page import="com.dao.postjobdao" %>
<%@ page import="com.model.Postjob" %>
<%@ page import="java.util.List" %>

<%
  UserModel u = (UserModel) session.getAttribute("Model");
  if (u == null) {
    response.sendRedirect("login.jsp");
    return;
  }

  CompanyDao companyDAO = new CompanyDao();
  postjobdao jobDAO     = new postjobdao();

  int totalCandidates   = companyDAO.getTotalApplications();
  int totalJobs         = jobDAO.getTotalJobs();
  int totalApplications = companyDAO.getTotalApplications();
  int totalCompanies    = companyDAO.getTotalCompanies();

  List<Postjob> postedJobs = jobDAO.getJobsByCompany(u.getEmail());
%>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>JobBoard — Company Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="shortcut icon" href="ftco-32x32.png">
  <link rel="stylesheet" href="css/custom-bs.css">
  <link rel="stylesheet" href="css/jquery.fancybox.min.css">
  <link rel="stylesheet" href="css/bootstrap-select.min.css">
  <link rel="stylesheet" href="fonts/icomoon/style.css">
  <link rel="stylesheet" href="fonts/line-icons/style.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/animate.min.css">
  <link rel="stylesheet" href="css/style.css">
  <style>
    .posted-jobs-table { background: #fff; border-radius: 10px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,.07); }
    .posted-jobs-table table { width: 100%; border-collapse: collapse; }
    .posted-jobs-table th { background: #f8fafc; padding: 12px 16px; font-size: 12px; font-weight: 600; color: #64748b; text-transform: uppercase; border-bottom: 1px solid #e2e8f0; text-align: left; }
    .posted-jobs-table td { padding: 14px 16px; font-size: 14px; color: #0f172a; border-bottom: 1px solid #f1f5f9; vertical-align: middle; }
    .posted-jobs-table tr:last-child td { border-bottom: none; }
    .posted-jobs-table tr:hover td { background: #f8fafc; }
    .badge-job { display: inline-block; padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: 500; }
    .badge-fulltime { background: #eff6ff; color: #1a56db; }
    .badge-parttime { background: #f0fdf4; color: #15803d; }
    .badge-contract { background: #fffbeb; color: #b45309; }
    .btn-sm-edit   { background: #eff6ff; color: #1a56db; border: 1px solid #bfdbfe; border-radius: 6px; padding: 4px 12px; font-size: 12px; text-decoration: none; }
    .btn-sm-delete { background: #fef2f2; color: #ef4444; border: 1px solid #fecaca; border-radius: 6px; padding: 4px 12px; font-size: 12px; text-decoration: none; margin-left: 4px; }
    .btn-sm-edit:hover   { background: #1a56db; color: #fff; }
    .btn-sm-delete:hover { background: #ef4444; color: #fff; }
    .empty-jobs { text-align: center; padding: 40px; color: #94a3b8; }
  </style>
</head>
<body id="top">

<div id="overlayer"></div>
<div class="loader">
  <div class="spinner-border text-primary" role="status">
    <span class="sr-only">Loading...</span>
  </div>
</div>

<div class="site-wrap">

  <div class="site-mobile-menu site-navbar-target">
    <div class="site-mobile-menu-header">
      <div class="site-mobile-menu-close mt-3">
        <span class="icon-close2 js-menu-toggle"></span>
      </div>
    </div>
    <div class="site-mobile-menu-body"></div>
  </div>

  <!-- NAVBAR -->
  <header class="site-navbar mt-3">
    <div class="container-fluid">
      <div class="row align-items-center">
        <div class="site-logo col-6"><a href="companyhome.jsp">JobBoard</a></div>
        <nav class="mx-auto site-navigation">
          <ul class="site-menu js-clone-nav d-none d-xl-block ml-0 pl-0">
            <li><a href="companyhome.jsp" class="nav-link active">Home</a></li>
            <li><a href="postjob.jsp">Post a Job</a></li>
            <li><a href="applicationview.jsp">Applications</a></li>
            <li class="has-children">
              <a href="#">Welcome, <%= u.getFirstname() %></a>
              <ul class="dropdown">
                <li><a href="companyprofile.jsp">View Profile</a></li>
                <li><a href="settings.jsp">Settings</a></li>
                <li><a href="logout">Logout</a></li>
              </ul>
            </li>
          </ul>
        </nav>
        <div class="right-cta-menu text-right d-flex aligin-items-center col-6">
          <div class="ml-auto">
            <a href="postjob.jsp" class="btn btn-outline-white border-width-2 d-none d-lg-inline-block">
              <span class="mr-2 icon-add"></span>Post a Job
            </a>
            <a href="logout" class="btn btn-primary border-width-2 d-none d-lg-inline-block">
              <span class="mr-2 icon-lock_outline"></span>Logout
            </a>
          </div>
          <a href="#" class="site-menu-toggle js-menu-toggle d-inline-block d-xl-none mt-lg-2 ml-3">
            <span class="icon-menu h3 m-0 p-0 mt-2"></span>
          </a>
        </div>
      </div>
    </div>
  </header>

  <!-- HERO -->
  <section class="home-section section-hero overlay bg-image" style="background-image: url('images/hero_1.jpg');" id="home-section">
    <div class="container">
      <div class="row align-items-center justify-content-center">
        <div class="col-md-12">
          <div class="mb-5 text-center">
            <h1 class="text-white font-weight-bold">Welcome, <%= u.getFirstname() %>!</h1>
            <p>Manage your job postings and track applications from one place.</p>
          </div>
          <form method="GET" action="joblistings.jsp" class="search-jobs-form">
            <div class="row mb-5">
              <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 mb-lg-0">
                <input type="text" name="keyword" class="form-control form-control-lg" placeholder="Job title, Company...">
              </div>
              <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 mb-lg-0">
                <select name="location" class="selectpicker" data-style="btn-white btn-lg" data-width="100%" data-live-search="true" title="Select Region">
                  <option value="">Anywhere</option>
                  <option value="ahmedabad">Ahmedabad</option>
                  <option value="surat">Surat</option>
                  <option value="mumbai">Mumbai</option>
                  <option value="bangalore">Bangalore</option>
                  <option value="delhi">Delhi</option>
                </select>
              </div>
              <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 mb-lg-0">
                <select name="jobType" class="selectpicker" data-style="btn-white btn-lg" data-width="100%" data-live-search="true" title="Select Job Type">
                  <option value="parttime">Part Time</option>
                  <option value="fulltime">Full Time</option>
                  <option value="contract">Contract</option>
                </select>
              </div>
              <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 mb-lg-0">
                <button type="submit" class="btn btn-primary btn-lg btn-block text-white btn-search">
                  <span class="icon-search icon mr-2"></span>Search Job
                </button>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12 popular-keywords">
                <h3>Quick Links:</h3>
                <ul class="keywords list-unstyled m-0 p-0">
                  <li><a href="postjob.jsp">Post a Job</a></li>
                  <li><a href="applicationview.jsp">Applications</a></li>
                  <li><a href="companyprofile.jsp">Edit Profile</a></li>
                </ul>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
    <a href="#next" class="scroll-button smoothscroll">
      <span class="icon-keyboard_arrow_down"></span>
    </a>
  </section>

  <!-- STATS -->
  <section class="py-5 bg-image overlay-primary fixed overlay" id="next" style="background-image: url('images/hero_1.jpg');">
    <div class="container">
      <div class="row mb-5 justify-content-center">
        <div class="col-md-7 text-center">
          <h2 class="section-title mb-2 text-white">JobBoard Site Stats</h2>
          <p class="lead text-white">Real-time numbers from our platform.</p>
        </div>
      </div>
      <div class="row pb-0 block__19738 section-counter">
        <div class="col-6 col-md-6 col-lg-3 mb-5 mb-lg-0">
          <div class="d-flex align-items-center justify-content-center mb-2">
            <strong class="number" data-number="<%= totalCandidates %>">0</strong>
          </div>
          <span class="caption">Candidates</span>
        </div>
        <div class="col-6 col-md-6 col-lg-3 mb-5 mb-lg-0">
          <div class="d-flex align-items-center justify-content-center mb-2">
            <strong class="number" data-number="<%= totalJobs %>">0</strong>
          </div>
          <span class="caption">Jobs Posted</span>
        </div>
        <div class="col-6 col-md-6 col-lg-3 mb-5 mb-lg-0">
          <div class="d-flex align-items-center justify-content-center mb-2">
            <strong class="number" data-number="<%= totalApplications %>">0</strong>
          </div>
          <span class="caption">Applications</span>
        </div>
        <div class="col-6 col-md-6 col-lg-3 mb-5 mb-lg-0">
          <div class="d-flex align-items-center justify-content-center mb-2">
            <strong class="number" data-number="<%= totalCompanies %>">0</strong>
          </div>
          <span class="caption">Companies</span>
        </div>
      </div>
    </div>
  </section>

  <!-- POSTED JOBS -->
  <section class="site-section py-5">
    <div class="container">
      <div class="row justify-content-center mb-5">
        <div class="col-md-7 text-center">
          <h2 class="section-title mb-2">Your Posted Jobs</h2>
          <p class="lead">Tmare post karela badha jobs ane teni details</p>
        </div>
      </div>
      <div class="posted-jobs-table">
        <% if (postedJobs == null || postedJobs.isEmpty()) { %>
          <div class="empty-jobs">
            <p style="font-size:14px;">Koi job post nathi karyo abhi sudhi.</p>
            <a href="postjob.jsp" class="btn btn-primary mt-2">+ Post First Job</a>
          </div>
        <% } else { %>
          <table>
            <thead>
              <tr>
                <th>#</th>
                <th>Job Title</th>
                <th>Type</th>
                <th>Location</th>
                <th>Salary</th>
                <th>Opening</th>
                <th>Applied</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <% int sr = 1; for (Postjob job : postedJobs) {
                String jt = job.getJob_Type() != null ? job.getJob_Type().toLowerCase() : "";
                String bc = jt.contains("full") ? "badge-fulltime" : jt.contains("part") ? "badge-parttime" : "badge-contract";
              %>
                <tr>
                  <td><%= sr++ %></td>
                  <td>
                    <strong><%= job.getJob_Title() %></strong>
                    <br><small style="color:#64748b;"><%= job.getExperience() %> yr exp &bull; <%= job.getSkills_req() %></small>
                  </td>
                  <td><span class="badge-job <%= bc %>"><%= job.getJob_Type() %></span></td>
                  <td><%= job.getLocation() %></td>
                  <td>&#8377;<%= job.getSalary() %></td>
                  <td><%= job.getOpening() %></td>
                  <td><strong style="color:#1a56db;"><%= job.getAppliedCount() %></strong></td>
                  <td>
                    <a href="editjob.jsp?id=<%= job.getJob_id() %>" class="btn-sm-edit">Edit</a>
                    <a href="deletejob.jsp?id=<%= job.getJob_id() %>"
                       onclick="return confirm('Delete karvu chhe?')"
                       class="btn-sm-delete">Delete</a>
                  </td>
                </tr>
              <% } %>	
            </tbody>
          </table>
        <% } %>
      </div>
      <div class="text-center mt-4">
        <a href="postjob.jsp" class="btn btn-primary btn-lg">
          <span class="icon-add mr-2"></span>Post New Job
        </a>
      </div>
    </div>
  </section>

  <!-- COMPANIES -->
  <section class="site-section py-4">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-12 text-center mt-4 mb-5">
          <div class="row justify-content-center">
            <div class="col-md-7">
              <h2 class="section-title mb-2">Company We've Helped</h2>
              <p class="lead">Porro error reiciendis commodi beatae omnis similique voluptate rerum ipsam fugit mollitia ipsum facilis expedita tempora suscipit iste</p>
            </div>
          </div>
        </div>
        <div class="col-6 col-lg-3 col-md-6 text-center"><img src="images/logo_mailchimp.svg" alt="Image" class="img-fluid logo-1"></div>
        <div class="col-6 col-lg-3 col-md-6 text-center"><img src="images/logo_paypal.svg" alt="Image" class="img-fluid logo-2"></div>
        <div class="col-6 col-lg-3 col-md-6 text-center"><img src="images/logo_stripe.svg" alt="Image" class="img-fluid logo-3"></div>
        <div class="col-6 col-lg-3 col-md-6 text-center"><img src="images/logo_visa.svg" alt="Image" class="img-fluid logo-4"></div>
        <div class="col-6 col-lg-3 col-md-6 text-center"><img src="images/logo_apple.svg" alt="Image" class="img-fluid logo-5"></div>
        <div class="col-6 col-lg-3 col-md-6 text-center"><img src="images/logo_tinder.svg" alt="Image" class="img-fluid logo-6"></div>
        <div class="col-6 col-lg-3 col-md-6 text-center"><img src="images/logo_sony.svg" alt="Image" class="img-fluid logo-7"></div>
        <div class="col-6 col-lg-3 col-md-6 text-center"><img src="images/logo_airbnb.svg" alt="Image" class="img-fluid logo-8"></div>
      </div>
    </div>
  </section>

  <!-- TESTIMONIALS -->
  <section class="bg-light pt-5 testimony-full">
    <div class="owl-carousel single-carousel">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 align-self-center text-center text-lg-left">
            <blockquote>
              <p>&ldquo;Soluta quasi cum delectus eum facilis recusandae nesciunt molestias accusantium libero dolores repellat id in dolorem laborum ad modi qui at quas dolorum voluptatem voluptatum repudiandae.&rdquo;</p>
              <p><cite>&mdash; Corey Woods, @Dribbble</cite></p>
            </blockquote>
          </div>
          <div class="col-lg-6 align-self-end text-center text-lg-right">
            <img src="images/person_transparent_2.png" alt="Image" class="img-fluid mb-0">
          </div>
        </div>
      </div>
      <div class="container">
        <div class="row">
          <div class="col-lg-6 align-self-center text-center text-lg-left">
            <blockquote>
              <p>&ldquo;Soluta quasi cum delectus eum facilis recusandae nesciunt molestias accusantium libero dolores repellat id in dolorem laborum ad modi qui at quas dolorum voluptatem voluptatum repudiandae.&rdquo;</p>
              <p><cite>&mdash; Chris Peters, @Google</cite></p>
            </blockquote>
          </div>
          <div class="col-lg-6 align-self-end text-center text-lg-right">
            <img src="images/person_transparent.png" alt="Image" class="img-fluid mb-0">
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- MOBILE APP -->
  <section class="pt-5 bg-image overlay-primary fixed overlay" style="background-image: url('images/hero_1.jpg');">
    <div class="container">
      <div class="row">
        <div class="col-md-6 align-self-center text-center text-md-left mb-5 mb-md-0">
          <h2 class="text-white">Get The Mobile Apps</h2>
          <p class="mb-5 lead text-white">Lorem ipsum dolor sit amet consectetur adipisicing elit tempora adipisci impedit.</p>
          <p class="mb-0">
            <a href="#" class="btn btn-dark btn-md px-4 border-width-2"><span class="icon-apple mr-3"></span>App Store</a>
            <a href="#" class="btn btn-dark btn-md px-4 border-width-2"><span class="icon-android mr-3"></span>Play Store</a>
          </p>
        </div>
        <div class="col-md-6 ml-auto align-self-end">
          <img src="images/apps.png" alt="Free Website Template by Free-Template.co" class="img-fluid">
        </div>
      </div>
    </div>
  </section>

  <!-- FOOTER -->
  <footer class="site-footer">
    <a href="#top" class="smoothscroll scroll-top">
      <span class="icon-keyboard_arrow_up"></span>
    </a>
    <div class="container">
      <div class="row mb-5">
        <div class="col-6 col-md-3 mb-4 mb-md-0">
          <h3>Search Trending</h3>
          <ul class="list-unstyled">
            <li><a href="#">Web Design</a></li>
            <li><a href="#">Graphic Design</a></li>
            <li><a href="#">Web Developers</a></li>
            <li><a href="#">Python</a></li>
            <li><a href="#">HTML5</a></li>
            <li><a href="#">CSS3</a></li>
          </ul>
        </div>
        <div class="col-6 col-md-3 mb-4 mb-md-0">
          <h3>Company</h3>
          <ul class="list-unstyled">
            <li><a href="#">About Us</a></li>
            <li><a href="#">Career</a></li>
            <li><a href="#">Blog</a></li>
            <li><a href="#">Resources</a></li>
          </ul>
        </div>
        <div class="col-6 col-md-3 mb-4 mb-md-0">
          <h3>Support</h3>
          <ul class="list-unstyled">
            <li><a href="#">Support</a></li>
            <li><a href="#">Privacy</a></li>
            <li><a href="#">Terms of Service</a></li>
          </ul>
        </div>
        <div class="col-6 col-md-3 mb-4 mb-md-0">
          <h3>Contact Us</h3>
          <div class="footer-social">
            <a href="#"><span class="icon-facebook"></span></a>
            <a href="#"><span class="icon-twitter"></span></a>
            <a href="#"><span class="icon-instagram"></span></a>
            <a href="#"><span class="icon-linkedin"></span></a>
          </div>
        </div>
      </div>
      <div class="row text-center">
        <div class="col-12">
          <p class="copyright"><small>
            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved |
            This template is made with <i class="icon-heart text-danger" aria-hidden="true"></i> by
            <a href="https://colorlib.com" target="_blank">Colorlib</a>
          </small></p>
        </div>
      </div>
    </div>
  </footer>

</div>

<!-- SCRIPTS -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/isotope.pkgd.min.js"></script>
<script src="js/stickyfill.min.js"></script>
<script src="js/jquery.fancybox.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.waypoints.min.js"></script>
<script src="js/jquery.animateNumber.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/bootstrap-select.min.js"></script>
<script src="js/custom.js"></script>

</body>
</html>