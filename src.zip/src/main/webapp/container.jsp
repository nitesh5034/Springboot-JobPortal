<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.model.UserModel" %>
<%@ page import="com.dao.postjobdao" %>
<%@ page import="com.model.Postjob" %>
<%@ page import="java.util.List" %>
<%
  UserModel u = (UserModel) session.getAttribute("Model");
  if (u == null) {
    response.sendRedirect("login.jsp");
    return;
  }
  postjobdao jobDAO = new postjobdao();
  List<Postjob> jobList = jobDAO.getAllJobs();
%>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>JobBoard — Find Your Dream Job</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="css/custom-bs.css">
  <link rel="stylesheet" href="fonts/icomoon/style.css">
  <link rel="stylesheet" href="fonts/line-icons/style.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/animate.min.css">
  <link rel="stylesheet" href="css/style.css">
  <style>
    :root {
      --blue:#1a56db; --dark:#0f172a; --accent:#f59e0b;
      --light:#f8fafc; --muted:#64748b; --border:#e2e8f0;
      --radius-sm:8px; --radius-md:12px; --radius-lg:20px;
      --shadow-sm:0 1px 3px rgba(0,0,0,.08);
      --shadow-md:0 4px 16px rgba(0,0,0,.10);
      --shadow-lg:0 12px 40px rgba(0,0,0,.14);
      --transition:all 0.25s cubic-bezier(.4,0,.2,1);
    }
    * { box-sizing:border-box; }
    body { font-family:'DM Sans',sans-serif; color:var(--dark); background:#fff; }
    .site-navbar { background:rgba(255,255,255,0.97); backdrop-filter:blur(12px); border-bottom:1px solid var(--border); padding:0; position:sticky; top:0; z-index:999; box-shadow:var(--shadow-sm); }
    .site-navbar .container-fluid { padding:14px 32px; }
    .site-logo a { font-family:'Sora',sans-serif; font-weight:700; font-size:22px; color:var(--dark) !important; text-decoration:none; }
    .site-logo a span { color:var(--blue); }
    .nav-link-item { font-size:14px; font-weight:500; color:var(--muted) !important; text-decoration:none; padding:7px 14px; border-radius:var(--radius-sm); transition:var(--transition); }
    .nav-link-item:hover { color:var(--blue) !important; background:#eff6ff; }
    .user-avatar { width:28px; height:28px; border-radius:50%; background:var(--blue); color:#fff; font-size:11px; font-weight:700; display:flex; align-items:center; justify-content:center; }
    .has-children { position:relative; }
    .has-children .dropdown { display:none; position:absolute; top:110%; left:0; min-width:180px; background:#fff; border:1px solid var(--border); border-radius:var(--radius-md); box-shadow:var(--shadow-lg); padding:8px 0; list-style:none; z-index:1000; }
    .has-children:hover .dropdown { display:block; }
    .has-children .dropdown li a { display:block; padding:9px 18px; font-size:13px; color:var(--muted); text-decoration:none; transition:var(--transition); }
    .has-children .dropdown li a:hover { color:var(--blue); background:#f8fafc; }
    .hero-section { background:linear-gradient(135deg,#0f172a 0%,#1e3a5f 50%,#1a56db 100%); min-height:520px; display:flex; align-items:center; position:relative; overflow:hidden; padding:80px 0; }
    .hero-section::before { content:''; position:absolute; inset:0; background:url('images/hero_1.jpg') center/cover no-repeat; opacity:0.1; }
    .hero-dots { position:absolute; inset:0; background-image:radial-gradient(circle,rgba(255,255,255,0.05) 1px,transparent 1px); background-size:32px 32px; }
    .hero-badge { display:inline-flex; align-items:center; gap:8px; background:rgba(255,255,255,0.12); border:1px solid rgba(255,255,255,0.2); border-radius:40px; padding:6px 16px; font-size:12px; color:rgba(255,255,255,0.85); margin-bottom:20px; }
    .hero-badge .dot { width:6px; height:6px; border-radius:50%; background:var(--accent); }
    .hero-section h1 { font-family:'Sora',sans-serif; font-size:clamp(28px,5vw,50px); font-weight:700; color:#fff; line-height:1.15; letter-spacing:-1px; margin-bottom:14px; }
    .hero-section h1 span { color:var(--accent); }
    .hero-section p.lead { color:rgba(255,255,255,0.7); font-size:15px; margin-bottom:32px; }
    .search-card { background:#fff; border-radius:var(--radius-lg); padding:10px; display:flex; gap:8px; align-items:center; box-shadow:var(--shadow-lg); flex-wrap:wrap; }
    .search-field { flex:1; min-width:160px; display:flex; align-items:center; gap:10px; padding:10px 16px; border-radius:var(--radius-md); border:1.5px solid transparent; transition:var(--transition); }
    .search-field:focus-within { border-color:var(--blue); background:#f0f6ff; }
    .search-field i { color:var(--muted); font-size:14px; }
    .search-field input,.search-field select { border:none; outline:none; background:transparent; font-size:14px; color:var(--dark); font-family:'DM Sans',sans-serif; width:100%; }
    .search-field input::placeholder { color:#94a3b8; }
    .search-divider { width:1px; height:36px; background:var(--border); flex-shrink:0; }
    .btn-search { background:var(--blue); color:#fff; border:none; border-radius:var(--radius-md); padding:12px 28px; font-size:14px; font-weight:600; cursor:pointer; transition:var(--transition); }
    .btn-search:hover { background:#1648c0; transform:translateY(-1px); }
    .trending-tags { margin-top:18px; display:flex; align-items:center; gap:8px; flex-wrap:wrap; justify-content:center; }
    .trending-tags span { color:rgba(255,255,255,0.6); font-size:12px; }
    .trending-tag { background:rgba(255,255,255,0.12); border:1px solid rgba(255,255,255,0.2); border-radius:40px; padding:3px 12px; font-size:11px; color:rgba(255,255,255,0.85); text-decoration:none; transition:var(--transition); }
    .trending-tag:hover { background:rgba(255,255,255,0.22); color:#fff; }
    .stats-section { background:var(--dark); padding:50px 0; }
    .stat-item { text-align:center; }
    .stat-number { font-family:'Sora',sans-serif; font-size:40px; font-weight:700; color:#fff; line-height:1; margin-bottom:6px; }
    .stat-label { font-size:12px; color:rgba(255,255,255,0.5); text-transform:uppercase; letter-spacing:1px; }
    .section-eyebrow { font-size:11px; font-weight:600; color:var(--blue); text-transform:uppercase; letter-spacing:2px; margin-bottom:8px; }
    .section-heading { font-family:'Sora',sans-serif; font-size:clamp(22px,4vw,34px); font-weight:700; color:var(--dark); letter-spacing:-0.5px; margin-bottom:10px; }
    .section-sub { font-size:14px; color:var(--muted); max-width:480px; margin:0 auto; }
    .job-card { background:#fff; border:1.5px solid var(--border); border-radius:var(--radius-md); padding:20px 24px; margin-bottom:14px; display:flex; align-items:center; justify-content:space-between; transition:var(--transition); cursor:pointer; }
    .job-card:hover { border-color:var(--blue); box-shadow:var(--shadow-md); transform:translateY(-2px); }
    .job-card h3 { font-size:15px; font-weight:600; color:var(--dark); margin-bottom:4px; }
    .company-name { font-size:13px; color:var(--blue); }
    .job-card .meta { font-size:12px; color:var(--muted); margin-top:6px; display:flex; align-items:center; gap:10px; flex-wrap:wrap; }
    .saved-badge { background:#f0fdf4; color:#15803d; border:1px solid #bbf7d0; border-radius:20px; padding:2px 10px; font-size:11px; margin-left:8px; }
    .badge-type { display:inline-block; padding:3px 10px; border-radius:20px; font-size:11px; font-weight:500; }
    .badge-fulltime { background:#eff6ff; color:#1a56db; }
    .badge-parttime { background:#f0fdf4; color:#15803d; }
    .badge-contract { background:#fffbeb; color:#b45309; }
    .btn-view-details { background:var(--blue); color:#fff; border:none; border-radius:var(--radius-sm); padding:7px 16px; font-size:12px; font-weight:600; cursor:pointer; transition:var(--transition); white-space:nowrap; }
    .btn-view-details:hover { background:#1648c0; }
    .job-modal-overlay { display:none; position:fixed; inset:0; background:rgba(0,0,0,0.55); z-index:9999; align-items:center; justify-content:center; padding:16px; }
    .job-modal-overlay.active { display:flex; }
    .job-modal-box { background:#fff; border-radius:20px; padding:32px; max-width:580px; width:100%; position:relative; max-height:88vh; overflow-y:auto; animation:slideUp 0.25s ease; }
    @keyframes slideUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
    .modal-close-btn { position:absolute; top:16px; right:16px; background:var(--light); border:none; border-radius:50%; width:34px; height:34px; font-size:16px; cursor:pointer; display:flex; align-items:center; justify-content:center; }
    .modal-close-btn:hover { background:var(--border); }
    .modal-company-logo { width:52px; height:52px; border-radius:var(--radius-sm); background:#eff6ff; border:1px solid var(--border); display:flex; align-items:center; justify-content:center; font-family:'Sora',sans-serif; font-size:20px; font-weight:700; color:var(--blue); margin-bottom:14px; }
    .modal-job-title { font-family:'Sora',sans-serif; font-size:22px; font-weight:700; color:var(--dark); margin-bottom:4px; }
    .modal-company { font-size:14px; color:var(--blue); margin-bottom:16px; }
    .modal-tags { display:flex; gap:8px; flex-wrap:wrap; margin-bottom:16px; }
    .modal-info-grid { display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:20px; }
    .modal-info-item { background:var(--light); border-radius:var(--radius-sm); padding:10px 14px; }
    .modal-info-label { font-size:11px; color:var(--muted); text-transform:uppercase; letter-spacing:0.5px; margin-bottom:2px; }
    .modal-info-value { font-size:14px; font-weight:600; color:var(--dark); }
    .modal-desc-title { font-size:13px; font-weight:600; color:var(--dark); margin-bottom:8px; }
    .modal-desc { font-size:13px; color:#475569; line-height:1.7; margin-bottom:16px; background:var(--light); border-radius:var(--radius-sm); padding:14px; }
    .skills-container { display:flex; gap:6px; flex-wrap:wrap; margin-bottom:20px; }
    .skill-tag { background:#eff6ff; color:var(--blue); border:1px solid #bfdbfe; border-radius:20px; padding:3px 12px; font-size:11px; font-weight:500; }
    .modal-actions { display:flex; gap:10px; flex-wrap:wrap; margin-bottom:20px; }
    .btn-apply-modal { background:var(--blue); color:#fff; border:none; border-radius:var(--radius-sm); padding:11px 24px; font-size:14px; font-weight:600; cursor:pointer; transition:var(--transition); }
    .btn-apply-modal:hover { background:#1648c0; }
    .btn-save-modal { background:#f0fdf4; color:#15803d; border:1px solid #bbf7d0; border-radius:var(--radius-sm); padding:11px 24px; font-size:14px; font-weight:600; cursor:pointer; }
    .btn-save-modal:hover { background:#dcfce7; }
    .btn-close-modal { background:var(--light); color:var(--muted); border:none; border-radius:var(--radius-sm); padding:11px 24px; font-size:14px; cursor:pointer; }
    .apply-form { display:none; border-top:1px solid var(--border); padding-top:20px; margin-top:4px; }
    .apply-form.active { display:block; }
    .apply-form h5 { font-family:'Sora',sans-serif; font-size:16px; font-weight:600; margin-bottom:16px; color:var(--dark); }
    .apply-form label { font-size:12px; color:var(--muted); margin-bottom:5px; display:block; font-weight:500; text-transform:uppercase; letter-spacing:0.5px; }
    .apply-form input,.apply-form textarea { width:100%; border:1.5px solid var(--border); border-radius:var(--radius-sm); padding:10px 14px; font-size:14px; margin-bottom:14px; font-family:'DM Sans',sans-serif; color:var(--dark); transition:var(--transition); }
    .apply-form input:focus,.apply-form textarea:focus { outline:none; border-color:var(--blue); }
    .apply-form textarea { resize:vertical; min-height:90px; }
    .btn-submit-apply { background:var(--blue); color:#fff; border:none; border-radius:var(--radius-sm); padding:11px 24px; font-size:14px; font-weight:600; cursor:pointer; }
    .btn-submit-apply:hover { background:#1648c0; }
    .companies-section { padding:50px 0; background:var(--light); }
    .companies-section img { filter:grayscale(100%); opacity:0.45; transition:var(--transition); }
    .companies-section img:hover { filter:none; opacity:1; }
    .testimonials-section { padding:70px 0; }
    .testimonial-card { background:var(--light); border-radius:var(--radius-lg); padding:32px; }
    .testimonial-card blockquote { font-size:16px; line-height:1.7; color:var(--dark); font-style:italic; border:none; margin-bottom:18px; }
    .testimonial-author { display:flex; align-items:center; gap:12px; }
    .t-avatar { width:42px; height:42px; border-radius:50%; background:var(--blue); color:#fff; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:14px; }
    .t-name { font-weight:600; font-size:14px; color:var(--dark); }
    .t-role { font-size:12px; color:var(--muted); }
    .cta-section { background:linear-gradient(135deg,#1a56db,#0f172a); padding:70px 0; text-align:center; }
    .cta-section h2 { font-family:'Sora',sans-serif; font-size:clamp(24px,4vw,38px); font-weight:700; color:#fff; letter-spacing:-0.5px; margin-bottom:10px; }
    .cta-section p { color:rgba(255,255,255,0.65); font-size:15px; margin-bottom:28px; }
    .btn-cta-white { background:#fff; color:var(--blue); border:none; border-radius:var(--radius-md); padding:12px 28px; font-size:14px; font-weight:600; text-decoration:none; display:inline-block; transition:var(--transition); }
    .btn-cta-white:hover { transform:translateY(-2px); box-shadow:0 8px 20px rgba(0,0,0,0.2); color:var(--blue); }
    .site-footer { background:var(--dark); padding:50px 0 24px; }
    .footer-brand { font-family:'Sora',sans-serif; font-size:18px; font-weight:700; color:#fff; margin-bottom:8px; }
    .footer-brand span { color:var(--accent); }
    .footer-desc { font-size:13px; color:rgba(255,255,255,0.4); line-height:1.7; max-width:220px; }
    .footer-heading { font-size:12px; font-weight:600; color:#fff; text-transform:uppercase; letter-spacing:1px; margin-bottom:14px; }
    .footer-links { list-style:none; padding:0; margin:0; }
    .footer-links li { margin-bottom:9px; }
    .footer-links a { font-size:13px; color:rgba(255,255,255,0.4); text-decoration:none; transition:var(--transition); }
    .footer-links a:hover { color:#fff; }
    .footer-divider { border-color:rgba(255,255,255,0.08); margin:36px 0 20px; }
    .footer-bottom { font-size:12px; color:rgba(255,255,255,0.3); text-align:center; }
    .social-links { display:flex; gap:8px; margin-top:14px; }
    .social-link { width:32px; height:32px; border-radius:50%; border:1px solid rgba(255,255,255,0.15); display:flex; align-items:center; justify-content:center; color:rgba(255,255,255,0.5); font-size:12px; text-decoration:none; transition:var(--transition); }
    .social-link:hover { border-color:var(--blue); color:#fff; background:var(--blue); }
    .empty-jobs { text-align:center; padding:60px 24px; color:var(--muted); }
    @media(max-width:768px) { .search-card{flex-direction:column;} .search-divider{display:none;} .btn-search{width:100%;} .modal-info-grid{grid-template-columns:1fr;} .job-card{flex-direction:column;align-items:flex-start;gap:12px;} }
  </style>
</head>
<body id="top">

<%-- HEADER INCLUDE --%>
<jsp:include page="header.jsp" />

<!-- HERO -->
<section class="hero-section">
  <div class="hero-dots"></div>
  <div class="container position-relative">
    <div class="row justify-content-center text-center">
      <div class="col-lg-9">
        <div class="hero-badge"><span class="dot"></span> Welcome back, <%= u.getFirstname() %>! 👋</div>
        <h1>Find Your <span>Dream Job</span><br>The Smarter Way</h1>
        <p class="lead">Browse thousands of jobs from top companies. Your next opportunity is just one search away.</p>
        <form method="GET" action="userhome.jsp">
          <div class="search-card">
            <div class="search-field">
              <i class="fas fa-search"></i>
              <input type="text" name="keyword" placeholder="Job title, skills or company...">
            </div>
            <div class="search-divider"></div>
            <div class="search-field">
              <i class="fas fa-map-marker-alt"></i>
              <select name="location">
                <option value="">Anywhere</option>
                <option value="ahmedabad">Ahmedabad</option>
                <option value="surat">Surat</option>
                <option value="mumbai">Mumbai</option>
                <option value="bangalore">Bangalore</option>
                <option value="delhi">Delhi</option>
                <option value="hyderabad">Hyderabad</option>
                <option value="remote">Remote</option>
              </select>
            </div>
            <div class="search-divider"></div>
            <div class="search-field">
              <i class="fas fa-briefcase"></i>
              <select name="jobType">
                <option value="">All Types</option>
                <option value="fulltime">Full Time</option>
                <option value="parttime">Part Time</option>
                <option value="contract">Contract</option>
                <option value="internship">Internship</option>
              </select>
            </div>
            <button type="submit" class="btn-search"><i class="fas fa-search me-2"></i>Search Jobs</button>
          </div>
        </form>
        <div class="trending-tags">
          <span>Trending:</span>
          <a href="#" class="trending-tag">Java</a>
          <a href="#" class="trending-tag">Python</a>
          <a href="#" class="trending-tag">React</a>
          <a href="#" class="trending-tag">UI/UX</a>
          <a href="#" class="trending-tag">DevOps</a>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- STATS -->
<section class="stats-section">
  <div class="container">
    <div class="row text-center g-4">
      <div class="col-6 col-md-3 stat-item">
        <div class="stat-number"><span class="number" data-number="1930">0</span>+</div>
        <div class="stat-label">Candidates</div>
      </div>
      <div class="col-6 col-md-3 stat-item">
        <div class="stat-number"><span class="number" data-number="540">0</span>+</div>
        <div class="stat-label">Jobs Posted</div>
      </div>
      <div class="col-6 col-md-3 stat-item">
        <div class="stat-number"><span class="number" data-number="320">0</span>+</div>
        <div class="stat-label">Jobs Filled</div>
      </div>
      <div class="col-6 col-md-3 stat-item">
        <div class="stat-number"><span class="number" data-number="150">0</span>+</div>
        <div class="stat-label">Companies</div>
      </div>
    </div>
  </div>
</section>

<!-- JOB LISTINGS -->
<section class="site-section py-5" style="background:var(--light);">
  <div class="container">
    <div class="text-center mb-5">
      <p class="section-eyebrow">Opportunities</p>
      <h2 class="section-heading">Latest Job Listings</h2>
      <p class="section-sub">Click any job to see full details, apply or save for later.</p>
    </div>
    <div id="jobsContainer">
      <% if (jobList == null || jobList.isEmpty()) { %>
        <div class="empty-jobs">
          <i class="fas fa-briefcase" style="font-size:40px;display:block;margin-bottom:12px;opacity:0.2;"></i>
          <p>No jobs available right now.</p>
        </div>
      <% } else { %>
        <% for (Postjob job : jobList) {
          String jt = job.getJob_Type() != null ? job.getJob_Type().toLowerCase() : "";
          String bc = jt.contains("full") ? "badge-fulltime" : jt.contains("part") ? "badge-parttime" : "badge-contract";
          String initial = job.getCompany_name() != null && !job.getCompany_name().isEmpty() ? String.valueOf(job.getCompany_name().charAt(0)).toUpperCase() : "J";
        %>
        <div class="job-card"
             data-id="<%= job.getJob_id() %>"
             data-title="<%= job.getJob_Title() != null ? job.getJob_Title().replace("\"","") : "" %>"
             data-company="<%= job.getCompany_name() != null ? job.getCompany_name().replace("\"","") : "" %>"
             data-location="<%= job.getLocation() != null ? job.getLocation() : "" %>"
             data-type="<%= job.getJob_Type() != null ? job.getJob_Type() : "" %>"
             data-salary="<%= job.getSalary() != null ? job.getSalary() : "" %>"
             data-experience="<%= job.getExperience() != null ? job.getExperience() : "" %>"
             data-opening="<%= job.getOpening() %>"
             data-region="<%= job.getJob_Region() != null ? job.getJob_Region() : "" %>"
             data-desc="<%= job.getJob_Description() != null ? job.getJob_Description().replace("\"","").replace("\n"," ") : "" %>"
             data-skills="<%= job.getSkills_req() != null ? job.getSkills_req() : "" %>"
             data-initial="<%= initial %>">
          <div style="display:flex;align-items:center;gap:16px;">
            <div style="width:48px;height:48px;border-radius:10px;background:#eff6ff;border:1px solid #bfdbfe;display:flex;align-items:center;justify-content:center;font-family:'Sora',sans-serif;font-size:18px;font-weight:700;color:#1a56db;flex-shrink:0;">
              <%= initial %>
            </div>
            <div>
              <h3><%= job.getJob_Title() %> <span class="company-name">@ <%= job.getCompany_name() %></span></h3>
              <div class="meta">
                <span class="badge-type <%= bc %>"><%= job.getJob_Type() %></span>
                <span><i class="fas fa-map-marker-alt me-1"></i><%= job.getLocation() %></span>
                <span><i class="fas fa-rupee-sign me-1"></i><%= job.getSalary() %></span>
                <span><i class="fas fa-clock me-1"></i><%= job.getExperience() %> yr exp</span>
              </div>
            </div>
          </div>
          <button class="btn-view-details">View Details</button>
        </div>
        <% } %>
      <% } %>
    </div>
  </div>
</section>

<!-- COMPANIES -->
<section class="companies-section">
  <div class="container">
    <div class="text-center mb-5">
      <p class="section-eyebrow">Trusted by</p>
      <h2 class="section-heading">Companies We've Helped</h2>
    </div>
    <div class="row align-items-center justify-content-center g-4">
      <div class="col-4 col-md-2 text-center"><img src="images/logo_mailchimp.svg" alt="Mailchimp" class="img-fluid" style="max-height:32px;"></div>
      <div class="col-4 col-md-2 text-center"><img src="images/logo_paypal.svg" alt="PayPal" class="img-fluid" style="max-height:32px;"></div>
      <div class="col-4 col-md-2 text-center"><img src="images/logo_stripe.svg" alt="Stripe" class="img-fluid" style="max-height:32px;"></div>
      <div class="col-4 col-md-2 text-center"><img src="images/logo_visa.svg" alt="Visa" class="img-fluid" style="max-height:32px;"></div>
      <div class="col-4 col-md-2 text-center"><img src="images/logo_apple.svg" alt="Apple" class="img-fluid" style="max-height:32px;"></div>
      <div class="col-4 col-md-2 text-center"><img src="images/logo_airbnb.svg" alt="Airbnb" class="img-fluid" style="max-height:32px;"></div>
    </div>
  </div>
</section>

<!-- TESTIMONIALS -->
<section class="testimonials-section">
  <div class="container">
    <div class="text-center mb-5">
      <p class="section-eyebrow">Success Stories</p>
      <h2 class="section-heading">What Job Seekers Say</h2>
    </div>
    <div class="row g-4">
      <div class="col-md-6">
        <div class="testimonial-card">
          <blockquote>"I found my dream job within 2 weeks of signing up. The search filters are incredibly helpful!"</blockquote>
          <div class="testimonial-author">
            <div class="t-avatar">CW</div>
            <div><div class="t-name">Corey Woods</div><div class="t-role">Senior Designer at Dribbble</div></div>
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="testimonial-card">
          <blockquote>"JobBoard helped me transition careers. The platform is clean, fast and easy to use!"</blockquote>
          <div class="testimonial-author">
            <div class="t-avatar" style="background:#10b981;">CP</div>
            <div><div class="t-name">Chris Peters</div><div class="t-role">Engineering Lead at Google</div></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- CTA -->
<section class="cta-section">
  <div class="container">
    <h2>Ready to Take the Next Step?</h2>
    <p>Update your profile and let employers find you faster.</p>
    <a href="newProfile.jsp" class="btn-cta-white">Update My Profile</a>
  </div>
</section>

<!-- FOOTER -->
<footer class="site-footer">
  <div class="container">
    <div class="row g-4 mb-4">
      <div class="col-md-4">
        <div class="footer-brand">Job<span>Board</span></div>
        <p class="footer-desc">The easiest way to connect talented professionals with top companies.</p>
        <div class="social-links">
          <a href="#" class="social-link"><i class="fab fa-facebook-f fa-xs"></i></a>
          <a href="#" class="social-link"><i class="fab fa-twitter fa-xs"></i></a>
          <a href="#" class="social-link"><i class="fab fa-instagram fa-xs"></i></a>
          <a href="#" class="social-link"><i class="fab fa-linkedin-in fa-xs"></i></a>
        </div>
      </div>
      <div class="col-6 col-md-2">
        <p class="footer-heading">For Job Seekers</p>
        <ul class="footer-links">
          <li><a href="userhome.jsp">Browse Jobs</a></li>
          <li><a href="newProfile.jsp">My Profile</a></li>
          <li><a href="applicationview.jsp">Applications</a></li>
        </ul>
      </div>
      <div class="col-6 col-md-2">
        <p class="footer-heading">Company</p>
        <ul class="footer-links">
          <li><a href="about.jsp">About Us</a></li>
          <li><a href="contact.jsp">Contact</a></li>
          <li><a href="#">Blog</a></li>
        </ul>
      </div>
      <div class="col-6 col-md-2">
        <p class="footer-heading">Support</p>
        <ul class="footer-links">
          <li><a href="#">FAQ</a></li>
          <li><a href="#">Privacy Policy</a></li>
          <li><a href="#">Terms</a></li>
        </ul>
      </div>
    </div>
    <hr class="footer-divider">
    <div class="footer-bottom">
      <p>&copy; <script>document.write(new Date().getFullYear());</script> JobBoard. All rights reserved.</p>
    </div>
  </div>
</footer>

<!-- MODAL -->
<div id="jobModal" class="job-modal-overlay">
  <div class="job-modal-box">
    <button class="modal-close-btn" id="modalClose">&times;</button>
    <div class="modal-company-logo" id="modalLogo">J</div>
    <div class="modal-job-title" id="modalTitle"></div>
    <div class="modal-company" id="modalCompany"></div>
    <div class="modal-tags" id="modalTags"></div>
    <div class="modal-info-grid">
      <div class="modal-info-item"><div class="modal-info-label">Location</div><div class="modal-info-value" id="modalLocation"></div></div>
      <div class="modal-info-item"><div class="modal-info-label">Salary</div><div class="modal-info-value" id="modalSalary"></div></div>
      <div class="modal-info-item"><div class="modal-info-label">Experience</div><div class="modal-info-value" id="modalExp"></div></div>
      <div class="modal-info-item"><div class="modal-info-label">Openings</div><div class="modal-info-value" id="modalOpening"></div></div>
    </div>
    <div class="modal-desc-title">Job Description</div>
    <div class="modal-desc" id="modalDesc"></div>
    <div class="modal-desc-title">Skills Required</div>
    <div class="skills-container" id="modalSkills"></div>
    <div class="modal-actions">
      <button class="btn-apply-modal" id="toggleApplyBtn"><i class="fas fa-paper-plane me-2"></i>Apply Now</button>
      <button class="btn-save-modal" id="saveJobBtn"><i class="fas fa-bookmark me-2"></i>Save Job</button>
      <button class="btn-close-modal" id="closeModalBtn">Close</button>
    </div>
    <div class="apply-form" id="applyForm">
      <h5>Apply for this Job</h5>
      <form id="applyJobForm" method="POST" action="ApplyServlet">
        <input type="hidden" name="jobId" id="applyJobId">
        <input type="hidden" name="jobTitle" id="applyJobTitle">
        <label>Your Name</label>
        <input type="text" name="name" value="<%= u.getFirstname() %> <%= u.getLastname() %>" required>
        <label>Your Email</label>
        <input type="email" name="email" value="<%= u.getEmail() %>" required>
        <label>Cover Letter</label>
        <textarea name="message" rows="4" placeholder="Why are you a good fit for this role?"></textarea>
        <div style="display:flex;gap:10px;margin-top:8px;">
          <button type="submit" class="btn-submit-apply"><i class="fas fa-paper-plane me-2"></i>Send Application</button>
          <button type="button" class="btn-close-modal" id="cancelApplyBtn">Cancel</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- SCRIPTS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
<script src="js/jquery.waypoints.min.js"></script>
<script src="js/jquery.animateNumber.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/custom.js"></script>
<script>
  function animateCounter(el) {
    const target = parseInt(el.getAttribute('data-number'));
    let current = 0; const inc = target/60;
    const timer = setInterval(() => {
      current += inc;
      if (current >= target) { current = target; clearInterval(timer); }
      el.textContent = Math.floor(current);
    }, 20);
  }
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(e => { if(e.isIntersecting){ animateCounter(e.target); obs.unobserve(e.target); } });
  }, {threshold:0.5});
  document.querySelectorAll('.number[data-number]').forEach(c => obs.observe(c));

  (function(){
    const modal = document.getElementById('jobModal');
    const applyForm = document.getElementById('applyForm');
    let selectedJob = null;

    function openModal(card) {
      selectedJob = card.dataset;
      document.getElementById('modalLogo').textContent     = card.dataset.initial || 'J';
      document.getElementById('modalTitle').textContent    = card.dataset.title;
      document.getElementById('modalCompany').textContent  = '@ ' + card.dataset.company;
      document.getElementById('modalLocation').textContent = card.dataset.location;
      document.getElementById('modalSalary').textContent   = '₹' + card.dataset.salary;
      document.getElementById('modalExp').textContent      = card.dataset.experience + ' years';
      document.getElementById('modalOpening').textContent  = card.dataset.opening + ' seats';
      document.getElementById('modalDesc').textContent     = card.dataset.desc || 'No description available.';
      document.getElementById('applyJobId').value          = card.dataset.id;
      document.getElementById('applyJobTitle').value       = card.dataset.title;
      const tagsEl = document.getElementById('modalTags');
      tagsEl.innerHTML = '';
      const jt = card.dataset.type || '';
      const bc = jt.toLowerCase().includes('full') ? 'badge-fulltime' : jt.toLowerCase().includes('part') ? 'badge-parttime' : 'badge-contract';
      tagsEl.innerHTML = '<span class="badge-type ' + bc + '">' + jt + '</span>';
      const skillsEl = document.getElementById('modalSkills');
      skillsEl.innerHTML = '';
      const skills = card.dataset.skills ? card.dataset.skills.split(',') : [];
      skills.forEach(s => {
        if(s.trim()){ const tag = document.createElement('span'); tag.className='skill-tag'; tag.textContent=s.trim(); skillsEl.appendChild(tag); }
      });
      applyForm.classList.remove('active');
      modal.classList.add('active');
      document.body.style.overflow = 'hidden';
    }

    function closeModal() {
      modal.classList.remove('active');
      applyForm.classList.remove('active');
      selectedJob = null;
      document.body.style.overflow = '';
    }

    document.getElementById('jobsContainer').addEventListener('click', function(e){
      const card = e.target.closest('.job-card');
      if(card) openModal(card);
    });
    document.getElementById('toggleApplyBtn').addEventListener('click', function(){ applyForm.classList.toggle('active'); });
    document.getElementById('saveJobBtn').addEventListener('click', function(){
      if(!selectedJob) return;
      const card = document.querySelector('.job-card[data-id="'+selectedJob.id+'"]');
      if(card && !card.querySelector('.saved-badge')){ const span=document.createElement('span'); span.className='saved-badge'; span.textContent='✓ Saved'; card.querySelector('h3').appendChild(span); }
      this.innerHTML='<i class="fas fa-check me-2"></i>Saved!'; this.style.background='#dcfce7';
    });
    document.getElementById('closeModalBtn').addEventListener('click', closeModal);
    document.getElementById('modalClose').addEventListener('click', closeModal);
    document.getElementById('cancelApplyBtn').addEventListener('click', function(){ applyForm.classList.remove('active'); });
    window.addEventListener('click', function(e){ if(e.target===modal) closeModal(); });
    document.addEventListener('keydown', function(e){ if(e.key==='Escape') closeModal(); });
  })();
</script>
</body>
</html>