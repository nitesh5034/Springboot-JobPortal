<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.model.UserModel" %>
<%
  UserModel u = (UserModel) session.getAttribute("Model");
%>

<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
  .site-navbar {
    background: rgba(255,255,255,0.97) !important;
    backdrop-filter: blur(12px);
    border-bottom: 1px solid #e2e8f0;
    position: sticky;
    top: 0;
    z-index: 999;
    box-shadow: 0 1px 8px rgba(0,0,0,.07);
    margin-top: 0 !important;
    padding: 0;
  }
  .site-navbar .container-fluid { padding: 12px 32px; }

  /* LOGO */
  .site-logo a {
    font-family: 'Sora', sans-serif !important;
    font-weight: 700 !important;
    font-size: 22px !important;
    color: #0f172a !important;
    text-decoration: none !important;
    letter-spacing: -0.5px;
  }
  .site-logo a span { color: #1a56db; }

  /* NAV LINKS */
  .site-menu > li > a {
    font-family: 'DM Sans', sans-serif !important;
    font-size: 14px !important;
    font-weight: 500 !important;
    color: #64748b !important;
    padding: 8px 14px !important;
    border-radius: 8px;
    transition: all 0.2s;
    text-decoration: none;
  }
  .site-menu > li > a:hover,
  .site-menu > li > a.active { color: #1a56db !important; background: #eff6ff; }

  /* DROPDOWN */
  .site-menu .dropdown {
    background: #fff !important;
    border: 1px solid #e2e8f0 !important;
    border-radius: 12px !important;
    box-shadow: 0 12px 40px rgba(0,0,0,.12) !important;
    padding: 8px 0 !important;
    min-width: 200px;
  }
  .site-menu .dropdown li a {
    padding: 9px 18px !important;
    font-size: 13px !important;
    color: #64748b !important;
    display: flex;
    align-items: center;
    gap: 8px;
    transition: all 0.2s;
  }
  .site-menu .dropdown li a:hover { color: #1a56db !important; background: #f8fafc; }

  /* USER PILL */
  .user-welcome a {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 40px;
    padding: 5px 14px 5px 5px;
    font-size: 13px;
    font-weight: 500;
    color: #0f172a !important;
    text-decoration: none;
    transition: all 0.2s;
  }
  .user-welcome a:hover { border-color: #1a56db; }
  .user-avatar-pill {
    width: 28px; height: 28px;
    border-radius: 50%;
    background: #1a56db;
    color: #fff;
    font-size: 11px;
    font-weight: 700;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-family: 'Sora', sans-serif;
  }

  /* LOGOUT LINK */
  .site-menu .dropdown li a[href="logout"] { color: #ef4444 !important; }
  .site-menu .dropdown li a[href="logout"]:hover { background: #fef2f2 !important; }

  /* LOGIN BUTTON */
  .btn-nav-login {
    background: #1a56db !important;
    color: #fff !important;
    border: none !important;
    border-radius: 8px !important;
    padding: 8px 20px !important;
    font-size: 13px !important;
    font-weight: 500 !important;
    font-family: 'DM Sans', sans-serif;
    text-decoration: none;
    transition: all 0.2s;
  }
  .btn-nav-login:hover { background: #1648c0 !important; color: #fff !important; }

  /* SEPARATOR in dropdown */
  .dropdown-separator {
    border-top: 1px solid #e2e8f0;
    margin: 6px 0;
  }
</style>

<!-- NAVBAR -->
<header class="site-navbar">
  <div class="container-fluid">
    <div class="row align-items-center">

      <!-- LOGO -->
      <div class="site-logo col-auto">
        <a href="userhome.jsp">Job<span>Board</span></a>
      </div>

      <!-- NAV LINKS -->
      <nav class="mx-auto site-navigation">
        <ul class="site-menu js-clone-nav d-none d-xl-block ml-0 pl-0" style="display:flex; gap:2px; list-style:none; margin:0; align-items:center;">
          <li><a href="userhome.jsp" class="nav-link active">Home</a></li>
          <li><a href="about.jsp">About</a></li>
          <li class="has-children">
            <a href="joblisting.jsp">Job Listings</a>
            <ul class="dropdown">
              <li><a href="jobsingle.jsp"><i class="fas fa-briefcase fa-xs"></i> Job Single</a></li>
            </ul>
          </li>
          <li><a href="blog.jsp">Blog</a></li>
          <li><a href="contact.jsp">Contact</a></li>

          <!-- USER MENU -->
          <li class="has-children">
            <% if (u != null) { %>
              <div class="user-welcome">
                <a href="#">
                  <span class="user-avatar-pill">
                    <%= u.getFirstname().substring(0,1).toUpperCase() %>
                  </span>
                  <%= u.getFirstname() %>
                </a>
              </div>
              <ul class="dropdown">
                <li><a href="newProfile.jsp"><i class="fas fa-user fa-xs"></i> View Profile</a></li>
                <li><a href="Setting.jsp"><i class="fas fa-cog fa-xs"></i> Settings</a></li>
                <li><a href="Application-track.jsp"><i class="fas fa-file-alt fa-xs"></i> My Applications</a></li>
                <li><a href="resumeupload.jsp"><i class="fas fa-file-upload fa-xs"></i> Resume</a></li>
                <li class="dropdown-separator"></li>
                <li><a href="logout"><i class="fas fa-sign-out-alt fa-xs"></i> Logout</a></li>
              </ul>
            <% } else { %>
              <a href="login.jsp">Login</a>
              <ul class="dropdown">
                <li><a href="login.jsp"><i class="fas fa-sign-in-alt fa-xs"></i> Login</a></li>
                <li><a href="register.jsp"><i class="fas fa-user-plus fa-xs"></i> Register</a></li>
              </ul>
            <% } %>
          </li>
        </ul>
      </nav>

      <!-- RIGHT BUTTONS -->
      <div class="right-cta-menu text-right d-flex align-items-center col-auto ms-auto">
        <div class="ml-auto d-none d-lg-flex align-items-center gap-2">
          <% if (u != null) { %>
            <a href="newProfile.jsp" style="background:transparent; color:#1a56db; border:1.5px solid #1a56db; border-radius:8px; padding:7px 18px; font-size:13px; font-weight:500; text-decoration:none;">
              My Profile
            </a>
            <a href="logout" class="btn-nav-login">Logout</a>
          <% } else { %>
            <a href="login.jsp" class="btn-nav-login">
              <i class="fas fa-lock me-1" style="font-size:11px;"></i> Log In
            </a>
          <% } %>
        </div>
        <a href="#" class="site-menu-toggle js-menu-toggle d-inline-block d-xl-none ml-3">
          <span class="icon-menu h3 m-0 p-0"></span>
        </a>
      </div>

    </div>
  </div>
</header>